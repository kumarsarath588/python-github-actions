from __future__ import absolute_import, division, print_function
__metaclass__ = type

from ..entity import Entity


class Prism(Entity):
    __BASEURL__ = "/api/nutanix/v3"
